//-----------------------------------------------------------------------
// <copyright file="SerializationNode.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.Serialization
{
    using System;

    /// <summary>
    /// Not yet documented.
    /// </summary>
    [Serializable]
    public struct SerializationNode
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        public string Name;

        /// <summary>
        /// Not yet documented.
        /// </summary>
        public EntryType Entry;

        /// <summary>
        /// Not yet documented.
        /// </summary>
        public string Data;
    }
}